package com.example.alimentos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {

    public Button btn_1;
    EditText username,pass,email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btn_1 =(Button) findViewById(R.id.button5);
        username = findViewById(R.id.editText3);
        pass = findViewById(R.id.editText);
        email= findViewById(R.id.editText2);

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (username.length()==0)
                {
                    username.setError("Enter Username");
                }

                else if (pass.length()==0){
                    pass.setError("Enter password");
                }

                else if (email.length()==0){
                    pass.setError("Enter email");
                }

                else {
                    btn_1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent intent_3 = new Intent(MainActivity2.this,activity_nav.class);
                            startActivity(intent_3);

                        }
                    });
                }
            }
        });

    }
}